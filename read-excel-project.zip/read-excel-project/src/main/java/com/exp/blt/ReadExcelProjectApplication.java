package com.exp.blt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReadExcelProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReadExcelProjectApplication.class, args);
	}

}
